import React from 'react';
import ReactDOM from 'react-dom';

const statePopCap = (
  stateHead,
  populationHead,
  capitalHead,
  state1,
  state1Pop,
  state1Cap,
  state2,
  state2Pop,
  state2Cap,
  state3,
  state3Pop,
  state3Cap,
  state4,
  state4Pop,
  state4Cap,
  state5,
  state5Pop,
  state5Cap,
  
) => {
return(
    <table>
        <tr>
            <th>{stateHead}</th>
            <th>{populationHead}</th>
            <th>{capitalHead}</th>
        </tr>
        <tr> 
            <td>{state1}</td>
            <td>{state1Pop}</td>
            <td>{state1Cap}</td>
        </tr>
        <tr> 
            <td>{state2}</td>
            <td>{state2Pop}</td>
            <td>{state2Cap}</td>
        </tr>
        <tr> 
            <td>{state3}</td>
            <td>{state3Pop}</td>
            <td>{state3Cap}</td>
        </tr>
        <tr> 
            <td>{state4}</td>
            <td>{state4Pop}</td>
            <td>{state4Cap}</td>
        </tr>
        <tr> 
            <td>{state5}</td>
            <td>{state5Pop}</td>
            <td>{state5Cap}</td>
        </tr>   
    
    
    </table>
);
};

ReactDOM.render(
  statePopCap(
    'State',
    'Population',
    'Capital',
    'Idaho',
    ' ',
    'Bosie',
    'Tennesse',
    '6.651 million',
    'Nashville',
    'Maine',
    '1.331 million',
    'Agust',
    'Wisconsin',
    '7.779 million',
    'Madison',
    'Texas',
    '28.768 million',
    'Austin',
  ),
  document.getElementById('root')
);