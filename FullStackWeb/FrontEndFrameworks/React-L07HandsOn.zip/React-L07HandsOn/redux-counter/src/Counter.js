import React from 'react';
import { connect } from 'react-redux';

class Counter extends React.Component {
  incrementA = () => {
    this.props.dispatch({
      type: 'IncrementA'
    });
  };

  incrementB = () => {
    this.props.dispatch({
      type: 'IncrementB'
    });
  };

  decrementC = () => {
    this.props.dispatch({
      type: 'DecrementC'
    });
  };
  
  decrementD = () => {
    this.props.dispatch({
      type: 'DecrementD'
    });
  };
  reset = () => {
    this.props.dispatch({
      type: 'Reset'
    });
  };

  render() {
    return (
      <div>
        <h2>Counter</h2>
        <div>
          
          <span>{this.props.count}</span>
          <br></br>
          <button onClick={this.incrementA}>Increase by 1</button>
          <br></br>
          <button onClick={this.incrementB}>Increase by 5</button>
          <br></br>
          <button onClick={this.decrementC}>Decrease by 1</button>
          <br></br>
          <button onClick={this.decrementD}>Decrease by 10</button>

          
          <br></br>
          <button onClick={this.reset}>Reset</button>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    count: state.count
  };
}

export default connect(mapStateToProps)(Counter);