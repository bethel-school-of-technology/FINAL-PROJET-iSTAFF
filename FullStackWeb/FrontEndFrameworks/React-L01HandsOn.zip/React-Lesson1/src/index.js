import React from 'react';
import ReactDOM from 'react-dom';

ReactDOM.render(
    React.createElement( 'div', {},
        React.createElement('ul', {}, 
        React.createElement('li', {}, 'Favorite Colors'),  
        React.createElement('ol',{}, 
            React.createElement('li',{}, 'Purple'),
            React.createElement('li',{}, 'Peacock'),
            React.createElement('li',{}, 'Teal'))),
     
    React.createElement('ul', {},
        React.createElement('li', {}, 'Favorite Music'),
        React.createElement('ol', {}, 
            React.createElement('li', {}, 'DC Talk'),
            React.createElement('li', {}, 'Carman'),
            React.createElement('li', {}, 'Kutless'))),


            React.createElement('ul', {},
            React.createElement('li', {}, 'Favorite Food'),
            React.createElement('ol', {}, 
                React.createElement('li', {}, 'Sushi'),
                React.createElement('li', {}, 'My Pizza'),
                React.createElement('li', {}, 'Green Thai Curry with Eggplant'))),
      
    React.createElement('ul', {},
            React.createElement('li', {}, 'Favorite Websites'),
            React.createElement('ol', {}, 
                React.createElement('li', {}, React.createElement('a', {'href':'http://www.https://www.zblendshemp.com/starsarahg/en/us/'}, 'The CBD')),
                React.createElement('li', {}, React.createElement('a', {'href':'https://www.zurvita.com/starsarahg/en/us/'}, 'For the Energy')),
                React.createElement('li', {}, React.createElement('a', {'href':'http://www.Salesforce.com'}, 'The Work (for now...)'))))),  
     
  
document.getElementById('root'));
















/*ReactDOM.render(React.createElement('ul', {}, 
React.createElement('ul', {}, 'Favorite Colors', 
    React.createElement('ol', {},
        React.createElement('li', {}, 'Purple',),
        React.createElement('li', {}, 'Teal',),
        React.createElement('li', {}, 'Peacock',)
), 
React.createElement('ul', {}, 'Favorite Movies', 
React.createElement('ol', {},   
React.createElement('li', {}, 'Itialian Job'),
React.createElement('li', {}, 'Red'),
React.createElement('li', {}, 'Oceans 11'),
),
React.createElement('ul', {}, 'Favorite Food', 
React.createElement('ol', {}, 'Sushi'),
React.createElement('li', {}, 'Pizza (mine only)'),
React.createElement('li', {}, 'Eggplant',
),
React.createElement('ul', {}, 'Favorite Websites'),
React.createElement('ol', {}, 
React.createElement('li', {}, React.createElement('a', {'href':'www.google.com' }, 'Google'))))))));
use the below

React.createElement('ul', {},
        React.createElement('li', {}, 'Favorite Food'),
        React.createElement('ol', {}, 
            React.createElement('li', {}, 'Sushi'),
            React.createElement('li', {}, 'My Pizza'),
            React.createElement('li', {}, 'Green Thai Curry with Eggplant'))),




React.createElement('ul', {},
        React.createElement('li', {}, 'Favorite Websites'),
        React.createElement('ol', {}, 
            React.createElement('li', {}, React.createElement('a', {'href':'http://www.https://www.zblendshemp.com/starsarahg/en/us/'}, 'The CBD')),
            React.createElement('li', {}, React.createElement('a', {'href':'https://www.zurvita.com/starsarahg/en/us/'}, 'The energy')),
            React.createElement('li', {}, React.createElement('a', {'href':'http://www.Salesforce.com'}, 'The Work')))),    


use the above

document.getElementById('root');*/
