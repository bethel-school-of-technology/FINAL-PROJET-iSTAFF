import React from "react";
import ReactDOM from "react-dom";

const App = props => {
    return <NumberOfStudents />;

};


    class NumberOfStudents extends React.Component {    
        constructor(props) {
            super(props);

            this.state = {
                enrolledStudents: 87,
                waitlistedStudents: 8,
                addStudent: 0
        };
        
    }

    increment(event) {
        this.setState({enrolledStudents: this.state.enrolledStudents + 1});
    }
    incrementA() {
        this.setState({enrolledStudents: this.state.enrolledStudents + parseInt(this.state.addStudent)}
        );
    }
    incrementB(event) {
        this.setState({waitlistedStudents: this.state.waitlistedStudents + 1});
    } 
    incrementC() {
        this.setState({waitlistedStudents: this.state.waitlistedStudents + parseInt(this.state.addStudent)}
        );
    }  
  
    render() {
        return (
            <div>
                <div>
                    <h1>Enrolled Students: {this.state.enrolledStudents}</h1>
                    <button onClick={this.increment.bind(this)}>Add 1 Enrolled Student</button>
                 
                    <h5>Add Multiple Enrolled Students:</h5>
                   
                    <input type="number" onChange={event => this.setState({ addStudent: event.target.value })}
                        value={this.state.addStudent}></input>
                    <button onClick={this.incrementA.bind(this)}>Increase Students</button>
                </div>

                <div>
                    <h1>Waitlisted Students: {this.state.waitlistedStudents}</h1>
                    <button onClick={this.incrementB.bind(this)}>Add 1 Waitlisted Student</button>

                    <h5>Add Multiple Waitelisted Students:</h5>
                    <input type="number" onChange={event => this.state({ addStudent: event.target.value })}
                        value={this.state.addStudent}></input>
                    <button onClick={this.incrementC.bind(this)}>Increase Students</button>
                </div>

               

            </div>
        );
    }
}



ReactDOM.render(<App />, document.getElementById('root'));