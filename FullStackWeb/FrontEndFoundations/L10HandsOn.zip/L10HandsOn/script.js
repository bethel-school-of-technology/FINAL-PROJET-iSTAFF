$("body").hover(function(){
    $("#pics").css({
        height: '+=10px',
        width: '+=10px'
    });
}); //how do you get it to stop getting bigger? 