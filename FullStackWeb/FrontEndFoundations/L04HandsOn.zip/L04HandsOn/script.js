class Employee {
    constructor(name, salary, hireDate) {
      this.name = name;
      this.salary = salary;
      this.hireDate = hireDate;
    }
    getName() {
      console.log(this.name.toUpperCase());
    }
    getSalary() {
      console.log(this.salary);
    }
    getHireDate() {
      console.log(this.hireDate);
    }
  }
  class Manager extends Employee{
    constructor(name, salary, hireDate, descriptionOfJob){
    super(name, hireDate, salary);
    this.descriptionOfJob = descriptionOfJob;
    }
    jobDescription(){
        console.log(this.name + " and makes " + this.salary + " was hired on "  + this.hireDate +  " because she is the " + this.descriptionOfJob + "and worth much more.");
    }
  }
  class Designer extends Employee {
    constructor(name, salary, hireDate, experience){
    super(name, hireDate, salary);
    this.experience = experience;
    }
    yearsExperience(){
        console.log(this.name + " earns "+ this.salary + " " + this.hireDate + " he was the perfect choice having had a " + this.experience + " in marketing.");
    }
  }
  class SalesAssociate extends Employee {
    constructor(name, salary, hireDate, degrees){
    super(name, salary, hireDate);
    this.degrees =  degrees;
    }
    degreeCompleted(){
        console.log(this.name + " earns " + this.salary + " she was hired on " + this.hireDate +  " and she has a " + this.degrees + " of diplomas.");
    }
  }
let Cindy = new Manager("Cindy Gooding", "2.8 Million dollas a year", "8/4/1983", "Manager of the household")
let Aaron = new Designer("Aaron Godinez", "150,000.00/year", "7/23/2019", "boat load")
let Debbie = new SalesAssociate("Debbie Dove", "$200,000.00/year", "7/24/1999", "mulitude")
Cindy.jobDescription();
Aaron.yearsExperience();
Debbie.degreeCompleted();