let newRequest = new XMLHttpRequest();
newRequest.onreadystatechange = function() {
  if (this.readyState == 4 && this.status == 200) {
    let info = JSON.parse(this.responseText);
    document.getElementById("name").innerHTML = info.name;
    document.getElementById("birthDate").innerHTML = info.birthDate;
 }
};
newRequest.open("GET", "einstein.json", true);
newRequest.send();

function bio() {
  let bioRequest = new XMLHttpRequest();
  bioRequest.onreadystatechange = function(){
    if (this.readyState ==4 && this.status == 200) {
      let einstein = JSON.parse(this.responseText);
      document.getElementById("bio").innerHTML = einstein.bio;
    }
  }

  bioRequest.open("GET", "einstein.json", true);
  bioRequest.send();
  };
 