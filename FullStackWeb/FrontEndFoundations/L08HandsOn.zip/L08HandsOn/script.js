$(document).ready(function(){
  $(".pTwo").hide();
  });
//googled w3school...for some reason it is a click anywhere on the page :( 
  $(document).click(function(){
    $(".pOne").text("jQuery is a fast, JavaScript library that makes many tasks easier and simpler to accomplish. A JavaScript library contains pre-written JavaScript which makes developing applications a bit easier for the developer. This means jQuery is not a language, but an extension of JavaScript. It takes many lines of JavaScript code, which we would have had to write ourselves before jQuery, and compresses it.");
  });

//also, i have to write document everywhere...why? shouldn't one at the top be good?
  $(document).dblclick(function(){
    $("li").hide();
  });

  $(document).hover(function(){
    $(".helpOne").css("background-color", "goldenrod");
      }, function(){
    $(".helpOne").css("background-color", "darkcyan")
  });

  $(document).keydown(function(){
    $("input").css("background-color", "red");
  }); //its like it's functional but not quite right...needs polishing :(


