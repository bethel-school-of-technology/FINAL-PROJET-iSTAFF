//button not working I don't understand, its too late and I'm too tired, I also feel like I'm making it WAY more complicated than it needed to be. 
const regexChecker= () => {
    document.getElementById('firstName').innerHTML;
    document.getElementById('lastName').innerHTML;
   
    testfirstName();
    testlastName ();
   
    const testfirstName = () => {
      var firstName = document.getElementById('firstName').value;
      
      var regex = /^[A-Z]+[a-z]+$/;
      
      test("firstName", firstName, regex);
    }
    const testlastName = () => {
        var lastName = document.getElementById('lastName').value;
        
        var regex = /^[A-Z]+[a-z]+$/;
        
      test("lastName", lastName, regex); 
    }
    
    const test= (regex) => {
      if ((firstName, lastName).match(regex)) {
        alert('Yay! Your inputs were all correct!');
        console.log(true);
      }
      else {
        alert('Oh no! Thats an invalid format!');
        console.log(false);
      }
    }
  }
  