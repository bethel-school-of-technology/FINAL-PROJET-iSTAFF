package com.example.demo;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/MyServlet")
public class ProjectServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1306151396634098221L;

	public void init() throws ServletException {
		super.init();
	}
	
	public void destroy() {
		super.destroy();
	}
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doGet was called");
		response.getWriter().append("Hello World!");
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doPost was called");
		//must enter '?name=<string value> to get name
		
		String myName = request.getParameter("name");
		String headerID = request.getHeader("Payload-Data");
		response.getWriter().append(headerID + " " +myName + " is understanding the code - Watch out world!");
		System.out.println(headerID);
	}
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doPut was called");
		response.setStatus(HttpServletResponse.SC_OK);
	}
	protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doDelete was called");
		response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
	}
	// o_o it all works! 
}
