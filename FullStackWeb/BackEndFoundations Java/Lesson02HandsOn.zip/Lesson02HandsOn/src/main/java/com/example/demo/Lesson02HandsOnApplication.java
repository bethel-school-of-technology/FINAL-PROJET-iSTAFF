package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;

@SpringBootApplication
@ServletComponentScan

public class Lesson02HandsOnApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lesson02HandsOnApplication.class, args);
		
		//first thought was to use and perfect the list array from the final...might still do that be I want a box on the website for the 
		//user to be able to fill...I think that will be shortly so fun!! 
	}

}
