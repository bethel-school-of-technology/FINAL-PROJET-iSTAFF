package com.finalproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lesson10FinalProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lesson10FinalProjectApplication.class, args);
	}

	
	//I cannot see how this will actually work, I tried sysout to no avail. postman returned the following:
	/*There was an error connecting to localhost:8080/user.
	Why this might have happened:
	The server couldn't send a response:
	Ensure that the backend is working properly
	Self-signed SSL certificates are being blocked:
	Fix this by turning off 'SSL certificate verification' in Settings > General
	Proxy configured incorrectly
	Ensure that proxy is configured correctly in Settings > Proxy
	Request timeout:
	Change request timeout in Settings > General*/
	
	//please don't think I stopped there, I'm way more stubborn than that. 
	//here are more errors

/*There was an error connecting to localhost:8080/post.
Why this might have happened:
The server couldn't send a response:
Ensure that the backend is working properly
Self-signed SSL certificates are being blocked:
Fix this by turning off 'SSL certificate verification' in Settings > General
Proxy configured incorrectly
Ensure that proxy is configured correctly in Settings > Proxy
Request timeout:
Change request timeout in Settings > General*/ 
	
	//It is basically the same message every time, so 
	//I did my best with the code, but no, I've not been able to actually see anything work
	//I tried to monkey around with MySQL (monkey because I had no actual idea what I was doing, 
			//but...it couldn't have hurt anything.
	//found the SSL certificates...I put it to every option available. NO HELP. 
	









}
