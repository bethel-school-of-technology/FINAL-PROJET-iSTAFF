package com.finalproject.account;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
  // default void findByUsername(String username) {
	//}







}