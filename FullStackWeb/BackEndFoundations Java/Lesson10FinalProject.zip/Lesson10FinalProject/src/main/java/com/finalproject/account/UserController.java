package com.finalproject.account;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")


public class UserController {
		
		@Autowired
		UserRepository UserRepository;

		
	    @Autowired
	    UserRepository dao;

	    @GetMapping("/user")
	    public List<User> getUser() {
	        List<User> foundUser = dao.findAll();
	        return foundUser;
	    }

	    @GetMapping("/user/{userId}")
	    public ResponseEntity<User> getPosts(@PathVariable(value="userId") Integer userId) {
	        User foundUser = dao.findById(userId).orElse(null);//it won't debug

	        if(foundUser == null) {
	            return ResponseEntity.notFound().header("Disallowed, Please Log-in.").build();
	        }
	        return ResponseEntity.ok(foundUser);
	    }

	    @PostMapping("/user")
	    public ResponseEntity<User> postUser(@RequestBody User user) {

	      
	        User createdUser = dao.save(user);

	        // RespEntity crafts response to include correct status codes.
	        return ResponseEntity.ok(createdUser);
	    }

	   //I don't think allowing users to delete their user info is a good idea.
	    //there needs to be a disable 
		
	}

