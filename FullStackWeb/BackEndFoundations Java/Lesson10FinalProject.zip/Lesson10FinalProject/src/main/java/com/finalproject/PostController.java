package com.finalproject;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/post")
public class PostController {
/*	repository
	get all posts
	get post by postId 
	post for posts , create one
	delete for posts
***PUT for posts, update  PUT/post/1 <- update post with ID 1 with props from body*/
	
	@Autowired
	PostRepository postRepository;

	
    @Autowired
    PostRepository dao;

    @GetMapping("/post")
    public List<Post> getPosts() {
        List<Post> foundPosts = dao.findAll();
        return foundPosts;
    }

    @GetMapping("/post/authId}")
    public ResponseEntity<Post> getPosts(@PathVariable(value="authId") Integer userId) {
        Post foundPosts = dao.findById(userId).orElse(null); 

        if(foundPosts == null) {
            return ResponseEntity.notFound().header("Disallowed, Please Log-in.").build();
        }
        return ResponseEntity.ok(foundPosts);
    }

    @PostMapping("/post")
    public ResponseEntity<Post> postPosts(@RequestBody Post post) {

        // saving to DB using instance of the repo interface
        Post createdPost = dao.save(post);

        // RespEntity crafts response to include correct status codes.
        return ResponseEntity.ok(createdPost);
    }

       
    
    
    @DeleteMapping("/post/{postId}")
    public ResponseEntity<Post> deleteMessage(@PathVariable(value="postId") Integer postId) {
        Post foundPosts = dao.findById(postId).orElse(null);

        if(foundPosts == null) {
            return ResponseEntity.notFound().header("Post","Nothing found with that post id").build();
        }else {
            dao.delete(foundPosts);
        }
        return ResponseEntity.ok().build();
    }
	
    
    
    
}
