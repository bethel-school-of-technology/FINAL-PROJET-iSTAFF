package com.finalproject;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="post")
public class Post {
	
			//id
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer postId; 
			//userId
	private Integer userId;//matches User
			//message
	private String message;
			
		//timeStamp
	//private String timeStamp; //local date/time and there is a format for that!!!!

	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyy-mm-dd HH:mm:ss a");
	LocalDateTime now = LocalDateTime.now();	
	private String timeStamp = now.format(formatter);
	
	
	
	
	public Integer getPostId() {
		return postId;
	}
	public void setPostId(Integer postId) {
		this.postId = postId;
	}
	public Integer getUserID() {
		return userId;
	}
	public void setUserID(Integer userID) {
		this.userId = userID;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	
	
	
	
}
