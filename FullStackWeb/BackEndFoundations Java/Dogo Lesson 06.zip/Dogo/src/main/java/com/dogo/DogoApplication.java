package com.dogo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DogoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DogoApplication.class, args);
	}

}
//so everything is showing up in the web address...in the console, Not sure if that is "right" 
//I do have a picture of what we are trying to do 
