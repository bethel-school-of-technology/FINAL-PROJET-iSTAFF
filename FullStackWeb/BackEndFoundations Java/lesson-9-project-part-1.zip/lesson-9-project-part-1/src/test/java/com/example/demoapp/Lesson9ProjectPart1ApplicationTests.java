package com.example.demoapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lesson9ProjectPart1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
