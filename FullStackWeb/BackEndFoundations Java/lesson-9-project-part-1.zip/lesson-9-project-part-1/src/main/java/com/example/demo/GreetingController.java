package com.example.demo;


import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetingController {

    //first curiosity, why did we label this lesson 9 when it is lesson 8 Hands-On?
}
//It wants be to create the Greeting Class...I made the class!!!
