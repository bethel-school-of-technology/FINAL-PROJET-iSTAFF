package com.example.demo;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

public class Greeting extends GreetingController {

	private static final String template = "Greetings, %s!";
    private final AtomicLong counter = new AtomicLong();

    public Greeting(long newCounter, String templateWithName) {
		// TODO Auto-generated constructor stub
	}

	@RequestMapping("/greeting")
    public Greeting greeting(@RequestParam(value="name", defaultValue="World") String name) {
          
    	
     // the counter value odd (i.e. 1, 3, 5, 7, ...)
            long newCounter = 0; //initialize
            newCounter = counter.get() * counter.incrementAndGet();
            String templateWithName = String.format(template, name);
            Greeting greetingObject = new Greeting(newCounter, templateWithName);
            return greetingObject;
    }
	
	//it wants me to remove the arguments for new Greeting or create a constructor...
    //created constructor 
	//? just curious...doesn't there need to be a 'get' somewhere so a name can be retrieved?
	//i'm not seeing a place where this code will 'get' so it will just always be the defaultValue....?
	
	
	
	
	
	
	
	
	
}
