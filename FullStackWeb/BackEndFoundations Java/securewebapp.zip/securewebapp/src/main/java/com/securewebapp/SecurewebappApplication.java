package com.securewebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurewebappApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurewebappApplication.class, args);
	}

}
