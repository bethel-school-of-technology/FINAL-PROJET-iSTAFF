package com.filmbuddy.controllers;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.filmbuddy.models.Actor;
import com.filmbuddy.models.Film;
import com.filmbuddy.models.Film_Actor;

@Controller
@RequestMapping({"/actors" })
public class ActorsController {
    @Value("${spring.datasource.url}")
    private String url;

    @Value("${spring.datasource.username}")
    private String username;

    @Value("${spring.datasource.password}")
    private String password;

	

	@GetMapping()
    public String getAllActors(Model model) {
        List<Actor> actors = new ArrayList<Actor>();
        List<Film> film = new ArrayList<Film>();
        List<Film_Actor> data = new ArrayList<Film_Actor>();
        
        
        // Code to query the database and
        // add actors to the List will go here
        Connection con;
        try {
            con = DriverManager.getConnection(url, username, password);
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(
         //		"SELECT * FROM actor "
        // "SELECT last_name as Actor, title as Film FROM actor JOIN film_actor ON actor_id JOIN film ON film_id"
       
           		"SELECT first_name, last_name, title  FROM actor "
       		 + "JOIN film_actor ON actor.actor_id = film_actor.actor_id "
            		
       	     + "JOIN film ON film.film_id = film_actor.film_id " 
            		
         //java.sql.SQLException: Column 'actor_id' not found. I've tried all things on this page 
         //I have to keep moving forward 
            		
            		
            );		
            		
            		
            		
           while (rs.next()) {
                // create a new Actor object
                Actor newActor = new Actor();
                Film newFilm = new Film();
                Film_Actor newData = new Film_Actor();
               
                // get the values from each column of the current row and add them to the new Album
                newActor.setActor_id(rs.getInt("actor_id"));
                newActor.setFirst_name(rs.getString("first_name"));
                newActor.setLast_name(rs.getString("last_name"));
                newFilm.setFilm_id(rs.getInt("film_id"));
                newFilm.setTitle(rs.getString("title"));
            	newData.setFilm_id(rs.getInt("film_id"));
            	newData.setActor_id(rs.getInt("actor_id"));
                
                
                
                
                // add the new actor to the actors list
                actors.add(newActor);
                film.add(newFilm);
                data.add(newData);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        

        model.addAttribute("view" );
        return "view";
   }
};